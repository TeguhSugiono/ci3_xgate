<?php

defined('BASEPATH') or exit('No direct script access allowed');

class C_formmenu extends CI_Controller {

    function __construct() {
        parent::__construct();
         $this->tpsonline = $this->load->database('tpsonline', TRUE);
         $this->mbatps = $this->load->database('mbatps', TRUE);

        if ($this->session->userdata('autogate_logged') <> 1) {
            redirect(site_url('login'));
        }
    }

    function index() {
        
//        $nocont = 'TGHU1234567';
//        print_r(substr($nocont, 0,4));
//        print_r(substr($nocont, 4,11));
//        die;
        
//        $name_principal = $this->m_model->getvalue('ptmsagate','name_principal','t_m_principal',array('rec_id' => 0,'code_principal' => 'TPS'));
//        echo $name_principal;
//        die;
        
//        $gate_in = $this->tpsonline->get_where('tbl_gate_in',array('id_cont_in' => NULL,'no_plat_mobil !=' => NULL));
//        echo $this->tpsonline->last_query();
//        die;
        
//        print_r($this->m_model->id_in());
//        die;
        
//        $data['a'] = 'ayam' ;
//        //print_r($data);
//        $data['a'] = 'bebek' ;
//        print_r($data);
//        die;
        
//        $data['a'] = 'ayam' ;
//        print_r($data);
//        array_push($data['a'], array('bebek'));
//        print_r($data);
//        die;

//        $result = $this->db->query("SELECT * from TRAN_OB where FLAG_SINKRON=0 ORDER BY pid asc")->result_array();
//        print_r($result);
//        die;
//        echo $this->session->userdata('autogate_logged');
//        echo $this->session->userdata('autogate_username');
//        echo $this->session->userdata('autogate_userid');
//        echo $this->session->userdata('autogate_thema');
//        die;

        $themaweb = $this->session->userdata('autogate_thema');
        $data = array(
            'menu_aktif' => 'dashboard',
            'content' => 'view',
            'themaweb' => $themaweb,
        );
        $this->load->view('formmenu/index', $data);
    }

    function c_tbl_gatein() {
        $select = '';
        $form = 'tbl_gate_in';

        $join = array();

        $where = array(
//            'flag_pengarang' => 0,
//            'flag_kategori' => 0,
//            'flag_penerbit' => 0,
//            'flag_tempat_terbit' => 0,
        );

        $where_term = array(
            'id_gate_in', 'no_kontainer','reff_code', 'no_plat_mobil', 'tgl_masuk', 'jam_masuk', 'tgl_keluar_trucking', 'jam_keluar_trucking', 'proses_gate_in','terminal','code_principal','vessel'
        );
        $column_order = array(
            Null, 'id_gate_in', 'no_kontainer','reff_code', 'no_plat_mobil', 'tgl_masuk', 'jam_masuk', 'tgl_keluar_trucking', 'jam_keluar_trucking', 'proses_gate_in','terminal','code_principal','vessel'
        );
        $order = array(
            'tgl_masuk' => 'asc',
            'jam_masuk' => 'asc'
        );
        $array_table = array(
            'select' => $select,
            'form' => $form,
            'join' => $join,
            'where' => $where,
            'where_like' => array(),
            'where_in' => array(),
            'where_not_in' => array(),
            'where_term' => $where_term,
            'column_order' => $column_order,
            'group' => '',
            'order' => $order,
        );

        $list = $this->m_tpsonline->get_datatables($array_table);
        $data = array();
        $no = $_POST['start'];

        foreach ($list as $field) {
            $no++;
            $row = array();

            $row[] = $no;
            $row[] = $field->id_gate_in;
            $row[] = $field->no_kontainer;
            $row[] = $field->reff_code;            
            $row[] = $field->no_plat_mobil;
            $row[] = showdate_dmy($field->tgl_masuk);
            $row[] = $field->jam_masuk;
            $row[] = showdate_dmy($field->tgl_keluar_trucking);
            $row[] = $field->jam_keluar_trucking;
            $row[] = $field->proses_gate_in;
            $row[] = $field->terminal;
            $row[] = $field->code_principal;
            $row[] = $field->vessel;

            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->m_tpsonline->count_all($array_table),
            "recordsFiltered" => $this->m_tpsonline->count_filtered($array_table),
            "data" => $data,
        );

        echo json_encode($output);
    }

    function c_tbl_gateout() {
        $select = '';
        $form = 'tbl_gate_out';

        $join = array();

        $where = array(
//            'flag_pengarang' => 0,
//            'flag_kategori' => 0,
//            'flag_penerbit' => 0,
//            'flag_tempat_terbit' => 0,
        );

        $where_term = array(
            'id_gate_out', 'no_transaksi', 'no_kontainer', 'no_plat_mobil', 'tgl_keluar', 'jam_keluar', 'tgl_masuk_trucking', 'jam_masuk_trucking', 'proses_gate_out'
        );
        $column_order = array(
            Null, 'id_gate_out', 'no_transaksi', 'no_kontainer', 'no_plat_mobil', 'tgl_keluar', 'jam_keluar', 'tgl_masuk_trucking', 'jam_masuk_trucking', 'proses_gate_out'
        );
        $order = array(
            'tgl_keluar' => 'asc',
            'jam_keluar' => 'asc'
        );
        $array_table = array(
            'select' => $select,
            'form' => $form,
            'join' => $join,
            'where' => $where,
            'where_like' => array(),
            'where_in' => array(),
            'where_not_in' => array(),
            'where_term' => $where_term,
            'column_order' => $column_order,
            'group' => '',
            'order' => $order,
        );

        $list = $this->m_tpsonline->get_datatables($array_table);
        $data = array();
        $no = $_POST['start'];

        foreach ($list as $field) {
            $no++;
            $row = array();

            $row[] = $no;
            $row[] = $field->id_gate_out;
            $row[] = $field->no_transaksi;
            $row[] = $field->no_kontainer;
            $row[] = $field->no_plat_mobil;
            $row[] = showdate_dmy($field->tgl_keluar);
            $row[] = $field->jam_keluar;
            $row[] = showdate_dmy($field->tgl_masuk_trucking);
            $row[] = $field->jam_masuk_trucking;
            $row[] = $field->proses_gate_out;

            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->m_tpsonline->count_all($array_table),
            "recordsFiltered" => $this->m_tpsonline->count_filtered($array_table),
            "data" => $data,
        );

        echo json_encode($output);
    }

    function c_tbl_ob() {
        $select = '';
        $form = 'TRAN_OB';

        $join = array();

        $where = array(
            'FLAG_SINKRON' => 0,
        );

        $where_term = array(
            'pid', 'NO_CONT', 'KD_TPS_ASAL'
        );
        $column_order = array(
            Null, 'pid', 'NO_CONT', 'KD_TPS_ASAL'
        );
        $order = array(
            'pid' => 'asc',
        );
        $array_table = array(
            'select' => $select,
            'form' => $form,
            'join' => $join,
            'where' => $where,
            'where_like' => array(),
            'where_in' => array(),
            'where_not_in' => array(),
            'where_term' => $where_term,
            'column_order' => $column_order,
            'group' => '',
            'order' => $order,
        );

        $list = $this->m_sql->get_datatables($array_table);
        $data = array();
        $no = $_POST['start'];

        foreach ($list as $field) {
            $no++;
            $row = array();

            $row[] = $no;
            $row[] = $field->pid;
            $row[] = $field->NO_CONT;
            
            if ($field->KD_TPS_ASAL == "TTL0") {
                $row[] = "PT Terminal Teluk Lamong";
            } elseif ($field->KD_TPS_ASAL == "TPS0") {
                $row[] = "PT Terminal Petikemas Surabaya (TPS)";
            } else {
                $row[] = "";
            }

            if ($field->GUDANG_TUJUAN == "CMBA") {
                $row[] = "TPS";
            } elseif ($field->GUDANG_TUJUAN == "GMBA") {
                $row[] = "PJT";
            } else {
                $row[] = "";
            }
            
            

            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->m_sql->count_all($array_table),
            "recordsFiltered" => $this->m_sql->count_filtered($array_table),
            "data" => $data,
        );

        echo json_encode($output);
    }

    function c_get_data_tpsonline() {
        $result = $this->db->query("SELECT * from TRAN_OB where FLAG_SINKRON=0 ORDER BY pid asc")->result_array();
        $a=0;
        $b=0;
        //$pesan_data = array('msg' => 'Tidak', 'queryinsert' => '','queryupdate' => '');
        
        foreach ($result as $row) {
            $pid = $row['pid'];
            
            if ($row['KD_TPS_ASAL'] == "TTL0") {
                $terminal = "PT Terminal Teluk Lamong";
            } elseif ($row['KD_TPS_ASAL'] == "TPS0") {
                $terminal = "PT Terminal Petikemas Surabaya (TPS)";
            } else {
                $terminal = "";
            }

            if ($row['GUDANG_TUJUAN'] == "CMBA") {
                $code_principal = "TPS";
            } elseif ($row['GUDANG_TUJUAN'] == "GMBA") {
                $code_principal = "PJT";
            } else {
                $code_principal = "";
            }
            
            $vessel = $row['NM_ANGKUT'].' '.$row['NO_VOY_FLIGHT'] ;
            
            if($row['UK_CONT'] == "20"){
                $reff_code = '2DS' ;
            }else{
                $reff_code = '4DS' ;
            }
            
            //$resultz = $this->db->query("SELECT * from TRAN_OB where pid=".$pid);
            //$querydata[$a++] = $this->db->last_query();
            
            //insert data ke tbl_gate_in
            $result = $this->tpsonline->query("insert into tbl_gate_in(no_kontainer,pid,terminal,code_principal,vessel,reff_code) 
                    values('".$row['NO_CONT']."','".$row['pid']."','".$terminal."','".$code_principal."','".$vessel."','".$reff_code."')");
            $queryinsert[$a++] = $this->tpsonline->last_query();
            if ($result >= 1) {
                $pesan_data = array( 'msg' => 'Ya', 'queryinsert' => $queryinsert);
            }else{
                $pesan_data = array('msg' => 'Tidak','queryinsert' => $queryinsert);
                echo json_encode($pesan_data);
            }
            
            $result = $this->db->query("Update TRAN_OB set  FLAG_SINKRON=1 where pid=".$pid);
            $queryupdate[$b++] = $this->db->last_query();

            if ($result >= 1) {
                $pesan_data = array( 'msg' => 'Ya', 'queryinsert' => $queryinsert, 'queryupdate' => $queryupdate);
            }else{
                $pesan_data = array('msg' => 'Tidak', 'queryinsert' => $queryinsert,'queryupdate' => $queryupdate);
                echo json_encode($pesan_data);
            }
        }

        echo json_encode($pesan_data);
    }

    function c_get_do_contout(){
        $result = $this->mbatps->query("SELECT * FROM tps_t_plp_do where FLAG_SINKRON=0 ORDER BY No_Transaksi asc")->result_array();
        
        $a=0;
        $b=0;
        $pesan_data = array('msg' => 'Tidak', 'queryinsert' => '','queryupdate' => '');
        
        foreach ($result as $row) {
            $No_Transaksi = $row['No_Transaksi'];
            
//            $resultz = $this->mbatps->query("SELECT * from tps_t_plp_do where No_Transaksi=".$No_Transaksi);
//            $queryinsert[$a++] = $this->mbatps->last_query();
            
            //insert data ke tbl_gate_out
            $result = $this->tpsonline->query("insert into tbl_gate_out(no_transaksi,no_kontainer) values('".$row['No_Transaksi']."','".$row['Cont_Number']."')");
            $queryinsert[$a++] = $this->tpsonline->last_query();
            if ($result >= 1) {
                $pesan_data = array( 'msg' => 'Ya', 'queryinsert' => $queryinsert);
            }else{
                $pesan_data = array('msg' => 'Tidak','queryinsert' => $queryinsert);
                echo json_encode($pesan_data);
            }
            
            $result = $this->mbatps->query("Update tps_t_plp_do set  FLAG_SINKRON=1 where No_Transaksi=".$No_Transaksi);
            $queryupdate[$b++] = $this->mbatps->last_query();

            if ($result >= 1) {
                $pesan_data = array( 'msg' => 'Ya', 'queryinsert' => $queryinsert, 'queryupdate' => $queryupdate);
            }else{
                $pesan_data = array('msg' => 'Tidak', 'queryinsert' => $queryinsert,'queryupdate' => $queryupdate);
                echo json_encode($pesan_data);
            }
            
        }
        
        echo json_encode($pesan_data);
        
    }
    
    function c_gate_in(){
//        INSERT INTO t_t_entry_cont_in (bon_bongkar_number, eir_in, code_principal, " +
//        "name_principal, cont_number, vessel, shipper, truck_number, driver_name, " +
//        "reff_code, reff_description, cont_condition, new_cont_condition, cont_status, new_cont_status, cont_date_in, " +
//        "cont_time_in, block_loc, location, ship_line_code, ship_line_name, invoice_in, plate, clean_type, " +
//        "clean_date, bc_code, bc_name, dangers_goods, notes, created_by, created_on, rec_id,seal_number,no_eir,tgl_eir,bruto)
        
        $gate_in = $this->tpsonline->get_where('tbl_gate_in',array('id_cont_in' => NULL,'no_plat_mobil !=' => NULL));
        $t_t_entry_cont_in = array();
        $t_t_stock = array();
        $t_eir = array();
        
        if($gate_in->num_rows() > 0){
            
            
            foreach($gate_in->result_array() as $row){
                $id_cont_in = $this->m_model->id_in();
                $bon_bongkar_number = $this->m_model->bon_bongkar_number();
                $eir_in = $this->m_model->eir_r_number();
                $code_principal = $row['code_principal'] ;
                $name_principal = $this->m_model->getvalue('ptmsagate','name_principal','t_m_principal',array('rec_id' => 0,'code_principal' => $code_principal));
                $no_kontainer = substr($row['no_kontainer'], 0,4)." ".substr($row['no_kontainer'], 4,11) ;
                $vessel = $row['vessel'];
                $reff_code = $row['reff_code'];
                $reff_description = $this->m_model->getvalue('ptmsagate','reff_description','t_m_refference',array('rec_id' => 0,'reff_code' => $reff_code));
                
                
                
                $t_t_entry_cont_in = array(
                    'id_cont_in'=>$id_cont_in,
                    'bon_bongkar_number'=>$bon_bongkar_number,
                    'eir_in'=>$eir_in,
                    'code_principal'=>$code_principal,
                    'name_principal'=>$name_principal,
                    'cont_number'=>$no_kontainer,
                    'dangers_goods'=>'No',
                    'vessel'=>$vessel,
                    'shipper'=>'.',
                    'truck_number'=>$row['no_plat_mobil'],
                    'driver_name'=>'',
                    'reff_code'=> $reff_code,
                    'reff_description'=>$reff_description,
                    'cont_condition'=>'AV',
                    'new_cont_condition'=>'AV',
                    'cont_status'=>'Full',
                    'new_cont_status'=>'Full',
                    'cont_date_in'=>$row['tgl_masuk'],
                    'cont_time_in'=>$row['jam_masuk'],
                    'block_loc'=>'.',
                    'location'=>'.. .. ..',
                    'ship_line_code'=>'.',
                    'ship_line_name'=>'.',
//                    'bc_code'=>'',
//                    'bc_name'=>'',
                    'invoice_in'=>'.',
                    'plate'=>'.',
                    'clean_type'=>'.',
                    'clean_date'=>NULL,
                    'notes'=>'.',
                    'created_by'=>'autogate system',
                    'created_on'=> tanggal_sekarang(),
                    'rec_id'=>0,
                    'bruto'=>0,
                );
                
                $indata = $this->m_model->Save_Data('ptmsagate','t_t_entry_cont_in',$t_t_entry_cont_in);
                
                if ($indata >= 1) {
                    $pesan_data = array('msg' => 'Ya','t_t_entry_cont_in' => $t_t_entry_cont_in);
                }else{
                    $pesan_data = array('msg' => 'Tidak','t_t_entry_cont_in' => $t_t_entry_cont_in);
                    echo json_encode($pesan_data);die;
                }
                
                $t_t_stock = array(
//                    'id_stock' => '',
                    'id_cont_in' => $id_cont_in,
                    'code_principal'=>$code_principal,
                    'name_principal'=>$name_principal,
                    'cont_number' => $no_kontainer,
                    'dangers_goods' => 'No',
                    'vessel' => $vessel,
                    'reff_code' => $reff_code,
                    'reff_description' => $reff_description,
                    'cont_condition' => 'AV',
                    'cont_status' => 'Full',
                    'cont_date_in' => $row['tgl_masuk'],
                    'cont_time_in' => $row['jam_masuk'],
//                    'cont_date_out' => '',
//                    'cont_time_out' => '',
//                    'do_number' => '',
                    'bon_bongkar_number' => $bon_bongkar_number,
//                    'bon_muat_number' => '',
                    'block_loc'=>'.',
                    'location'=>'.. .. ..',
                    'ship_line_code'=>'.',
                    'ship_line_name'=>'.',
//                    'bc_code' => '',
                    'notes' => '.',
//                    'date_shifting' => '',
//                    'date_stripping' => '',
//                    'date_stuffing' => '',
                    'invoice_in' => '.',
                    'created_by'=>'autogate system',
                    'created_on'=> tanggal_sekarang(),
                    'rec_id' => 0,
//                    'seal_number' => '',
//                    'no_eir' => '',
//                    'tgl_eir' => '',
//                    'No_Transaksi' => '',
                    'bruto' => 0,
                );
                
                $stockdata = $this->m_model->Save_Data('ptmsagate','t_t_stock',$t_t_stock);
                
                if ($stockdata >= 1) {
                    $pesan_data = array('msg' => 'Ya','t_t_entry_cont_in' => $t_t_entry_cont_in,'t_t_stock' => $t_t_stock);
                }else{
                    $pesan_data = array('msg' => 'Tidak','t_t_entry_cont_in' => $t_t_entry_cont_in,'t_t_stock' => $t_t_stock);
                    echo json_encode($pesan_data);die;
                }
                
                $t_eir = array(
//                    'id_eir_number'=>'',
                    'eir_type'=>'I',
                    'eir_number'=>$eir_in,
                    'bon_bongkar_number'=>$bon_bongkar_number,
//                    'bon_muat_number'=>'',
                    'code_principal'=>$code_principal,
                    'name_principal'=>$name_principal,
                    'cont_number'=>$no_kontainer,
//                    'do_number'=>'',
                    'vessel'=>$vessel,
//                    'shipper'=>'',
                    'truck_number'=>$row['no_plat_mobil'],
                    'driver_name'=>'',
                    'reff_code' => $reff_code,
                    'reff_description' => $reff_description,
                    'cont_condition'=>'AV',
                    'cont_status'=>'Full',
                    'cont_date_in' => $row['tgl_masuk'],
                    'cont_time_in' => $row['jam_masuk'],
//                    'cont_date_out'=>'',
//                    'cont_time_out'=>'',
//                    'destination'=>'',
//                    'seal_number'=>'',
                    'block_loc'=>'.',
                    'location'=>'.. .. ..',
                    'notes'=>'.',
                    'created_by'=>'autogate system',
                    'created_on'=> tanggal_sekarang(),
//                    'edited_by'=>'',
//                    'edited_on'=>'',
                    'rec_id'=>0,
//                    'no_eir'=>'',
//                    'tgl_eir'=>'',
//                    'No_Transaksi'=>'',
                    'bruto'=>0
                );
                
                $eirdata = $this->m_model->Save_Data('ptmsagate','t_eir',$t_eir);
                
                if ($eirdata >= 1) {
                    $pesan_data = array('msg' => 'Ya','t_t_entry_cont_in' => $t_t_entry_cont_in,'t_t_stock' => $t_t_stock,'t_eir' => $t_eir);
                }else{
                    $pesan_data = array('msg' => 'Tidak','t_t_entry_cont_in' => $t_t_entry_cont_in,'t_t_stock' => $t_t_stock,'t_eir' => $t_eir);
                    echo json_encode($pesan_data);die;
                }
                
                $data_tblgatein = array(
                    'id_cont_in' => $id_cont_in
                );
                $gatein_update = $this->m_model->Update_Data('tpsonline','tbl_gate_in',$data_tblgatein,array('id_gate_in' => $row['id_gate_in']));
                
                if ($gatein_update >= 1) {
                    $pesan_data = array('msg' => 'Ya','t_t_entry_cont_in' => $t_t_entry_cont_in,'t_t_stock' => $t_t_stock,'t_eir' => $t_eir,'data_tblgatein' => $data_tblgatein);
                }else{
                    $pesan_data = array('msg' => 'Tidak','t_t_entry_cont_in' => $t_t_entry_cont_in,'t_t_stock' => $t_t_stock,'t_eir' => $t_eir,'data_tblgatein' => $data_tblgatein);
                    echo json_encode($pesan_data);die;
                }
                
                $update_eir_r_number = $this->m_model->update_eir_r_number();
                
            }
            
        }else{
            $pesan_data = array('msg' => 'Tidak','pesan' => 'Tidak Ada Data Yang Di Proses...');
            echo json_encode($pesan_data);die;
        }
        
        echo json_encode($pesan_data);
        
    }
    
    function c_gate_out(){
        
    }
    
}
