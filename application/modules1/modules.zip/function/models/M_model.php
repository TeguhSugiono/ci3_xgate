<?php

defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

class M_model extends CI_Model {

    function __construct() { // untuk awalan membuat class atau lawan kata nya index
        parent::__construct();
        $this->jobpjt = $this->load->database('jobpjt', TRUE);
        $this->mbatps = $this->load->database('mbatps', TRUE);
        $this->ptmsagate = $this->load->database('ptmsagate', TRUE);
        $this->ptmsadbo = $this->load->database('ptmsadbo', TRUE);
        $this->tpsonline = $this->load->database('tpsonline', TRUE);
    }
    
   function cek_data($table, $where = "") {
        $data = $this->jobpjt->get_where($table, $where);
        return $data;
    }
    
    function bon_bongkar_number(){
        $query = "SELECT bon_bongkar_number FROM t_t_entry_cont_in WHERE rec_id = '0' ORDER BY bon_bongkar_number desc limit 1";
        $data = $this->ptmsagate->query($query);
        if($data->num_rows() > 0){
            foreach ($data->result() as $row) {
                $dpt = $row->bon_bongkar_number;
                $intdpt = (int)$dpt ;
                $intdpt++;
            }
        }else{
            $intdpt = 1 ;
        }
        return str_pad($intdpt, 5, "0", STR_PAD_LEFT) ;
    }
    
    function eir_r_number(){
        $query = "SELECT r_eir_in as no FROM r_number";
        $data = $this->ptmsagate->query($query);
        $dpt = $data->row()->no;        
        if($dpt == 0 || $dpt == ""){
            $dpt = 1 ;
        }        
        $intdpt = (int)$dpt ;        
        return str_pad($intdpt, 5, "0", STR_PAD_LEFT) ;
    }
    
    function update_eir_r_number(){
        $query = "update r_number set r_eir_in = r_eir_in + 1";
        $data = $this->ptmsagate->query($query);
        return $data ;
    }
    
    function id_in(){
        $query = "SELECT id_cont_in FROM t_t_entry_cont_in ORDER BY id_cont_in desc limit 1";
        $data = $this->ptmsagate->query($query);
        if($data->num_rows() > 0){
            foreach ($data->result() as $row) {
                $dpt = $row->id_cont_in;
                $intdpt = (int)$dpt ;
                $intdpt++;
            }
        }else{
            $intdpt = 1 ;
        }
        return str_pad($intdpt, 5, "0", STR_PAD_LEFT) ;
    }
    
    function getvalue($database,$select = '', $form = '', $where = array(), $limit = '', $orderby = '') {
        $this->$database->select($select);
        $this->$database->from($form);
        $this->$database->where($where);

        if ($orderby != '') {
            $this->$database->order_by($orderby);
        }

        if ($limit != '') {
            $this->$database->limit($limit);
        }

        $data = $this->$database->get();
//        echo $this->db->last_query();
//        die;
        $dpt = '';
        foreach ($data->result() as $row) {
            $dpt = $row->$select;
        }
        return $dpt;
    }
    
    public function Save_Data($database,$table, $data)
    {
        $data = $this->$database->insert($table, $data);
        // echo $this->$database->last_query();
        // die;
        return $data;
    }
    
    public function Update_Data($database,$table, $data, $where)
    {
        $res = $this->$database->update($table, $data, $where);
        // echo $this->$database->last_query();
        // die;
        return $res;
    }

}
